import numpy as np
import SimpleITK as sitk
import glob, os, cv2
import matplotlib.pyplot as plt
from skimage import measure

def get_image_path_by_id(patient_id, image_dir):
    
    file_name = [os.path.relpath(os.path.join(image_dir, x)) \
                    for x in os.listdir(image_dir) \
                    if os.path.isfile(os.path.join(image_dir, x)) and patient_id in x]
    if len(file_name)>0:
        return file_name[0]
    else:
        return ''
    
    
def seg_in_roi_by_screenshots(img_nii_path,seg_nii_path,screenshots_dir,patient_id):  

    
    slice_folder = screenshots_dir +'/' + patient_id + '_jpack/'
    if not os.path.isdir(slice_folder ):
        os.mkdir(slice_folder )  

    im_sitk = sitk.ReadImage(img_nii_path)
    im_array  = sitk.GetArrayFromImage(im_sitk)       
    auto_seg_sitk = sitk.ReadImage(seg_nii_path)
    auto_seg_array  = sitk.GetArrayFromImage(auto_seg_sitk)    
    print('im_array.shape[0]', im_array.shape[0], 'auto_seg_array.shape[0]',auto_seg_array.shape[0])
    
    hu_min, hu_max = 0, 1000

    im_array[im_array < hu_min] = hu_min
    im_array[im_array > hu_max] = hu_max  #  40L 350W
    
    roi_slice_list = []

    for k in range(im_array.shape[0]-1):
        if ( np.sum(auto_seg_array[k,:,:])!=0):
            roi_slice_list.append(k)   
    slice_min, slice_max = np.min(roi_slice_list), np.max(roi_slice_list)
    slice_min = np.max([slice_min - 2, 0])
    slice_max = np.min([slice_max + 3, im_array.shape[0]-1])
    print('slice_min', slice_min, ' slice_max',slice_max, ' im_array.shape[0]', im_array.shape[0])
    

    for i in range(slice_min, slice_max):
        slice_png_path = slice_folder + patient_id +'_slice'+str(i) + '_' + str(im_array.shape[0] -1 ) +'.png'
        if not os.path.exists(slice_png_path):
#         if True:        
            fig, ax = plt.subplots()
            im_array_slice = im_array[i,:,:]           

            auto_seg_slice = auto_seg_array[i,:,:]
            color_list = ['lightgreen', 'yellow', 'red', 'cyan']
            
            
            
            if 'ID' in patient_id:
                auto_seg_slice = np.flipud(auto_seg_slice)
                im_array_slice = np.flipud(im_array_slice)
            ax.imshow(im_array_slice, cmap=plt.cm.gray)
            for voxel_class in range(1,5):           
            
                array_plot = np.copy(auto_seg_slice)
                array_plot[array_plot != voxel_class] = 0
                array_plot[array_plot != 0] = voxel_class
                contours_1 = measure.find_contours(array_plot, 0.5)
                for n, contour in enumerate(contours_1):
                    ax.plot(contour[:, 1], contour[:, 0], linewidth= 1, color= color_list[voxel_class -1] )                 
                
            ax.set_xticks([])
            ax.set_yticks([])
            fig.set_size_inches(8, 8)
            plt.title(patient_id+'_slice:'+str(i) + '/' + str(im_array.shape[0] -1 ))
            fig.savefig(slice_png_path , dpi=256)
            plt.close('all')
#         print(slice_folder +'slice'+str(i)+'.png: saved') 
    return 





img_dir = '../gu-project/MRI_code_and_data/data_curation/MRI_Data_515/412_training_set/412_training_img_in_nii/'
seg_dir = '../gu-project/MRI_code_and_data/data_curation/MRI_Data_515/412_training_set/412_training_seg_prd_nii/'
screenshots_dir  = '../gu-project/MRI_code_and_data/data_curation/MRI_Data_515/412_training_set/412_training_jpack/'

img_dir = '../gu-project/MRI_code_and_data/data_curation/MyoSegmenTUM/img_water_nii_L2-L5/'
seg_dir = '../gu-project/MRI_code_and_data/data_curation/MyoSegmenTUM/seg_water_nii_L2-L5/'
screenshots_dir  = '../gu-project/MRI_code_and_data/data_curation/MyoSegmenTUM/jpack_water_L2-L5/'

img_dir = 'nnUNet_raw_data_base/nnUNet_test_data/test_img_in_nii_515/'
seg_dir = 'nnUNet_raw_data_base/nnUNet_test_data/test_seg_in_nii_raw/'
screenshots_dir = 'nnUNet_raw_data_base/nnUNet_test_data/Test_Jpack/MRI515/'

pid_list = []
for idx, d in enumerate(sorted(os.listdir(seg_dir))):
    if '.nii.gz' in d :
        indices = [i for i, c in enumerate(d) if c == '_']
        pid = d[:indices[2]]        
#         if len(indices)>2 and '_3d' not in d and 'ID' not in d  and 'Tass' not in d:
#             pid = d[:indices[2]]
        print(idx, pid,'processing')

        img_path = get_image_path_by_id(pid, img_dir)
        seg_path = get_image_path_by_id(pid, seg_dir)
        
        print( 'img_path:', img_path)
        print('seg_path:' ,seg_path)
        if os.path.exists(img_path) and os.path.exists(seg_path):
            seg_in_roi_by_screenshots(img_path,seg_path,screenshots_dir,pid)
            print('\n',pid,'jpack saved into the dir :\n', screenshots_dir, '\n\n')
